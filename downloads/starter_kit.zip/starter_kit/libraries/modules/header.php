<header>
    <div class="container-lg">
        <div class="utilities">
            <a href="#" class="icon" type="chat">Chat</a>
            <a href="#" class="icon" type="mobile">1-800-409-4502</a>
            <a href="#" class="account">
                John Doe
                <div class="avatar xs male"></div>
            </a>
            <a href="#" class="icon" type="cart">
               <span class="notice"></span>
            </a>
        </div>
        <a href="home" class="branding"></a>
        <div class="search">
            <span class="icon" type="search"></span>
            <input type="search" placeholder="Search gear &amp; clothing" class="borderless" />
        </div>
    </div>
</header>
