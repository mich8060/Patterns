<div class="select-option" value="{value}">
	<img src="{image}" alt="" />
	<div class="select-options-label">{name}</div>
</div>