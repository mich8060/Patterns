<dropdown class="brands">
    <div class="container-md text-center">
        <div class="row">
            <div class="col-lg-12">Shop Over A Thousand Brands</div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <a href="all-brands#num">#</a>
                <a href="all-brands#A">A</a> 
                <a href="all-brands#B">B</a>
                <a href="all-brands#C">C</a>
                <a href="all-brands#D">D</a>
                <a href="all-brands#E">E</a>
                <a href="all-brands#F">F</a>
                <a href="all-brands#G">G</a>
                <a href="all-brands#H">H</a>
                <a href="all-brands#I">I</a>
                <a href="all-brands#J">J</a>
                <a href="all-brands#K">K</a>
                <a href="all-brands#L">L</a>
                <a href="all-brands#M">M</a>
                <a href="all-brands#N">N</a>
                <a href="all-brands#O">O</a>
                <a href="all-brands#P">P</a>
                <a href="all-brands#Q">Q</a>
                <a href="all-brands#R">R</a>
                <a href="all-brands#S">S</a>
                <a href="all-brands#T">T</a>
                <a href="all-brands#U">U</a>
                <a href="all-brands#V">V</a>
                <a href="all-brands#W">W</a>
                <a href="all-brands#X">X</a>
                <a href="all-brands#Y">Y</a>
                <a href="all-brands#Z">Z</a>
            </div>
        </div>
    </div>
</dropdown>