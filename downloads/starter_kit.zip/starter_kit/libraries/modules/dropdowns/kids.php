<dropdown>
    <div class="container-md">
        <div class="col-lg-3">
            <strong><a href="#">Boys</a></strong>
            <a href="#">Outerwear</a>
            <a href="#">Clothing</a>
            <a href="#">Footwear</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Girls</a></strong>
            <a href="#">Outerwear</a>
            <a href="#">Clothing</a>
            <a href="#">Footwear</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Toddlers &amp; Infants</a></strong>
            <a href="#">Outerwear</a>
            <a href="#">Clothing</a>
            <a href="#">Footwear</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Accessories</a></strong>
            <a href="#">Headwear</a>
            <a href="#">Eyewear</a>
            <a href="#">Gloves &amp; Mittens</a>
            <a href="#">Strollers &amp; Joggers</a>
        </div>
    </div>
</dropdown>