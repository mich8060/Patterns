<dropdown>
    <div class="container-lg">
        <div class="row">
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-3"><img src="img/navigation/exclusive_backcountry.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusives_basin_and_range.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusive_folsom.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusives_haglofs.png" alt="" /></div>
                </div>
            </div> 
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-3"><img src="img/navigation/exclusives_houdini.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusives_norrona.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusives_uber.png" alt="" /></div>
                    <div class="col-lg-3"><img src="img/navigation/exclusives_whitedot.png" alt="" /></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
				<div class="gap10"></div>
				<hr class="sm" />
			</div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <a href="#">Men</a>
                <a href="#">Women</a>
                <a href="#">Kids</a>
                <a href="#">Footwear</a>
                <a href="#">Accessories</a>
                <a href="#">Hike &amp; Camp</a>
                <a href="#">Ski</a>
                <a href="#">Snowboard</a>
            </div>
        </div>
    </div>
</dropdown>