<dropdown>
    <div class="container-md">
        <div class="col-lg-3">
            <strong><a href="#">Men</a></strong>
            <a href="#">Outerwear</a>
            <a href="#">Clothing</a>
            <a href="#">Footwear</a>
            <a href="#">Accessories</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Women</a></strong>
            <a href="#">Outerwear</a>
            <a href="#">Clothing</a>
            <a href="#">Footwear</a>
            <a href="#">Accessories</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Kids</a></strong>
            <a href="#">Boys' Clothing</a>
            <a href="#">Girls' Clothing</a>
            <a href="#">Toddler</a>
            <a href="#">Infant</a>
            <a href="#">Accessories</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Shop By Activity</a></strong>    
            <a href="#">Hike &amp; Camp</a>
            <a href="#">Bike</a>
            <a href="#">Ski</a>
            <a href="#">Snowboard</a>
            <a href="#">Paddle</a>
            <a href="#">Fly Fish</a>
        </div>
    </div>
</dropdown>