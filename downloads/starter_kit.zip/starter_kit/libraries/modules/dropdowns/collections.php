<dropdown class="collections">
    <div class="container-lg">
        <div class="row">
            <div class="col-lg-3">
                <a href="#">
                    <img src="img/navigation/32450_SF2.jpg" alt="" />
                    <div class="collections-headline">Maximum Style &amp; Warmth</div>
                    <div class="collections-subheadline">Canada Goose, Parajumpers, G-Lab, &amp; More</div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="#">
                    <img src="img/navigation/32599_SF2.jpg" alt="" />
                    <div class="collections-headline">Marmot Down Jackets</div>
                    <div class="collections-subheadline">Warmth for City, Trail, &amp; Slopes</div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="#">
                    <img src="img/navigation/31994_SF2.jpg" alt="" />
                    <div class="collections-headline">Hunter Boots &amp; Apparel</div>
                    <div class="collections-subheadline">Iconic Style &amp; Enduring Function</div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="#">
                    <img src="img/navigation/30438_SF2.jpg" alt="" />
                    <div class="collections-headline">Our Most Versatile Insulated Jackets</div>
                    <div class="collections-subheadline">Down for Whatever</div>
                </a>
            </div>
        </div>
    </div>
</dropdown>