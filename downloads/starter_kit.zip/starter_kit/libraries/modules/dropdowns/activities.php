<dropdown class="activities">
    <div class="container-lg">
        <div class="row">
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_ski.jpg);" data="Ski"></a></div>
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_snowboard.jpg);" data="Snowboard"></a></div>
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_hike.jpg);" data="Fly Fish"></a></div>
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_bike.jpg);" data="Bike"></a></div>
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_climb.jpg);" data="Climb"></a></div>
            <div class="col-lg-2"><a href="#" style="background-image:url(img/navigation/dropdown_fitness.jpg);" data="Fitness"></a></div>
        </div>		
        <div class="row">
            <div class="col-lg-12">
				<div class="gap10"></div>
				<hr class="sm" />
			</div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <a href="#">Hike &amp; Camp</a>
                <a href="#">Run</a>
                <a href="#">Paddle</a>
                <a href="#">Surf</a>
                <a href="#">Snowshoe</a>
                <a href="#">Travel</a>
            </div>
        </div>
    </div>
</dropdown>