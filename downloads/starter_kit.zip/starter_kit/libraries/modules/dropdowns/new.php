<dropdown>
    <div class="container-md">
        <div class="col-lg-3">
            <strong><a href="#">Women</a></strong>
            <a href="#">Tops</a>
            <a href="#">Pants</a>
            <a href="#">Dresses &amp; Skirts</a>
            <a href="#">Jackets</a>
            <a href="#">Swimwear</a>
            <a href="#">Accessories</a>
            <a href="#">Footwear</a>
            <a href="#">Shop All</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Men</a></strong>
            <a href="#">Shirts</a>
            <a href="#">Pants</a>
            <a href="#">Shorts</a>
            <a href="#">Hoodies &amp; Sweaters</a>
            <a href="#">Jackets</a>
            <a href="#">Accessories</a>
            <a href="#">Footwear</a>
            <a href="#">Shop All</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Gear</a></strong>
            <a href="#">Backpack</a>
            <a href="#">Hike &amp; Camp</a>
            <a href="#">Climb</a>
            <a href="#">Fly Fishing</a>
            <a href="#">Surf &amp; Paddle</a>
            <a href="#">Fitness</a>
            <a href="#">Accessories</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Brands</a></strong>
            <a href="#">Reigning Champ</a>
            <a href="#">Body Language</a>
            <a href="#">Spot Satellite</a>
            <a href="#">Tepui</a>
            <a href="#">Totem Cams</a>
            <a href="#">Alchemy Equipment</a>
            <a href="#">Duckworth</a>
        </div>
    </div>
</dropdown>