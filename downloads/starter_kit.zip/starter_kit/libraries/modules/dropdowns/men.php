<dropdown>
    <div class="container-md">
        <div class="col-lg-3">
            <strong><a href="#">Clothing</a></strong>
            <a href="mens">Jackets</a>
            <a href="#">Hoodies &amp; Sweaters</a>
            <a href="#">Shirts</a>
            <a href="#">Pants</a>
            <a href="#">Shorts</a>
            <a href="#">Baselayers</a>
            <a href="#">Underwear</a>
            <a href="#">Swimwear</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Footwear</a></strong>
            <a href="#">Boots</a>
            <a href="#">Shoes</a>
            <a href="#">Sandals</a>
            <a href="#">Slippers</a>
            <a href="#">Socks</a>
            <a href="#">All</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Accessories</a></strong>
            <a href="#">Head &amp; Neck Wear</a>
            <a href="#">Eyewear</a>
            <a href="#">Gloves &amp; Mittens</a>
            <a href="#">Electronics</a>
            <a href="#">Watches</a>
            <a href="#">Backpacks &amp; Bags</a>
            <a href="#">Blankets</a>
            <a href="#">All</a>
        </div>
        <div class="col-lg-3">
            <strong><a href="#">Shop By Activity</a></strong>
            <a href="#">Ski</a>
            <a href="#">Snowboard</a>
            <a href="#">Fitness</a>
            <a href="#">Hike &amp; Camp</a>
            <a href="#">Climb</a>
            <a href="#">Run</a>
            <a href="#">Fly Fish</a>
            <a href="#">Bike</a>
        </div>
    </div>
</dropdown>