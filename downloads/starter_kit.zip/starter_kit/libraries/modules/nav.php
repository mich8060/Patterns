<nav>
    <ul>
        <li>
            <a href="#" class="primary">Exclusives</a>
            <dropdown template="exclusives"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">New Arrivals</a>
            <dropdown template="new"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Collections</a>
            <dropdown template="collections"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Brands</a>
            <dropdown template="brands"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Activities</a>
            <dropdown template="activities"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Women</a>
            <dropdown template="women"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Men</a>
            <dropdown template="men"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Kids</a>
            <dropdown template="kids"></dropdown>
        </li>
        <li>
            <a href="#" class="primary">Sale</a>
            <dropdown template="sale"></dropdown>
        </li>
    </ul>
</nav>