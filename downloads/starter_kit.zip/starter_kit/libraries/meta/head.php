<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" />
<link rel="apple-touch-icon" sizes="57×57" href="img/favicons/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon" sizes="114×114" href="img/favicons/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon" sizes="72×72" href="img/favicons/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon" sizes="144×144" href="img/favicons/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon" sizes="60×60" href="img/favicons/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon" sizes="120×120" href="img/favicons/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon" sizes="76×76" href="img/favicons/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon" sizes="152×152" href="img/favicons/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon" sizes="180x180" href="img/favicons/apple-touch-icon-180x180.png" />
<link rel="icon" type="image/png" sizes="16×16" href="img/favicons/favicon-16x16.png" />
<link rel="icon" type="image/png" sizes="32×32" href="img/favicons/favicon-32x32.png" />
<link rel="icon" type="image/png" sizes="96×96" href="img/favicons/favicon-96x96.png" />
<link rel="icon" type="image/png" sizes="160×160" href="img/favicons/favicon-160x160.png" />
<link rel="shortcut icon" tyle="image/x-icon" href="img/favicons/favicon.ico" />
<link rel="stylesheet" href="css/screen.css?<?php echo time(); ?>" />
</head>