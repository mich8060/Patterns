<div class="guide-header">
	<div class="container-lg">
		<a href="#" class="brand"><img src="img/layout/backcountry@3x.png" alt="" /></a>
		<a href="#" class="hamburger"><img src="img/layout/backcountry_hamburger@3x.jpg" alt="" /></a>
		<div class="guide-nav">
			<a href="#">Intro</a>
		    <a href="#">Getting Started</a>
		    <a href="#" class="selected">Library</a>
		    <a href="#">Team</a>
		    <a href="#">Lab</a>
		    <a href="#" class="downloads">Downloads</a>
		</div>
	</div>
</div>