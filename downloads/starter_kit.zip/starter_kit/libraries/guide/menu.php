<div class="guide-hamburger">
	<a href="#">Intro</a>
    <a href="#">Getting Started</a>
    <a href="#" class="selected">Patterns</a>
    <a href="#">Team</a>
    <a href="#">Lab</a>
    <a href="#" class="downloads">Downloads</a>
</div>